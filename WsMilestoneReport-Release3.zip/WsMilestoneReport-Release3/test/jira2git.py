# coding=utf-8

import web
import json
import re, textwrap
import os, sys, argparse
from datetime import datetime as dt
import time, calendar
import subprocess, shutil, stat
import copy, multiprocessing, threading
import socket
from gherkin.parser import Parser
#from json2html import *

parser = argparse.ArgumentParser()
parser.add_argument('--web_ip', default='localhost',  type=str)
parser.add_argument('--web_port', default=5000,  type=int)
parser.add_argument('--web_addr', default='0.0.0.0:5000', type=str)
parser.add_argument('--git_project', default='git@xil01ugitapp01p.newco.global:web-team/webapps.git',  type=str)
parser.add_argument('--git_branch', default='Nex-Workstation-Infastructure',  type=str)
parser.add_argument('--git_folder', default='webapps',  type=str)
parser.add_argument('--features_path', default='code/webapps/packages/nex-workstation-e2e/features/scenarios',  type=str)
parser.add_argument('--report_ts', default=None,  type=str)
args = parser.parse_args()



def getIp4():
    ips = [i[4][0] for i in socket.getaddrinfo(socket.gethostname(), None)]
    if len(ips) >= 6:
        return ips[6] #ipv4
    else:
        return 'localhost'


def isPortOpen(ip,port):
   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   try:
      s.connect((ip, int(port)))
      s.shutdown(2)
      return True
   except:
      return False


def t():
    #return dt.now().strftime("%d%m%Y%H%M%S%f") #strftime("%d-%m-%Y_%H-%M-%S_%f")
    return calendar.timegm(time.gmtime())


def rmtree(top):
    for root, dirs, files in os.walk(top, topdown=False):
        for name in files:
            filename = os.path.join(root, name)
            os.chmod(filename, stat.S_IWUSR)
            os.remove(filename)
        for name in dirs:
            os.rmdir(os.path.join(root, name))
    os.rmdir(top)


def rmreports():
    try:
        days = 21
        now = time.time()
        path = 'static/data'
        json_files = [f for f in os.listdir(path) if '.json' in f]
        json_to_remove = [f for f in json_files if os.path.getmtime(os.path.join(path, f)) < now - days * 86400]
        [os.remove(os.path.join(path, f)) for f in json_to_remove]
    except:
        pass


def runCmd(cmd):
    print('Starting cmd: %s' % cmd)
    subprocess.Popen(cmd, shell=True)


def printExcInfo():
    exc_type, exc_value, exc_tb = sys.exc_info()
    printj('\nException Info:\n%s\n%s\nFile: %s\n%s' % (exc_type, exc_value, exc_tb.tb_frame.f_code.co_filename, exc_tb.tb_lineno))

def u(list2uniq):
    return list(dict.fromkeys(list2uniq))

def val(obj, num=True):
    try:
        if num and not isinstance(obj, int):
            print('Expected Int, Actual %s' % obj)
            return 0
        else:
            return obj
    except:
        print('Exception for %s' % obj)
        if num:
            return 0
        else:
            return ''


def isDefined(var):
    try:
        return var
    except: #NameError:
        return None



MAIN_REPORT = ""
STORIES_REPORT = ""
SCENARIOS_REPORT = ""
BUGS_REPORT = ""
NOT_MAPPED_SCENARIOS_REPORT = ""
NOT_MAPPED_STORIES_REPORT = ""
NOT_MAPPED_BUGS_REPORT = ""
JENKINS_REPORT = ""
def initReports():
    rmreports()
    args.web_addr = '%s:%s' % (getIp4(), args.web_port)
    if args.report_ts is None:
        args.report_ts = t()
        tt = args.report_ts
    try:
        global MAIN_REPORT
        global STORIES_REPORT
        global SCENARIOS_REPORT
        global BUGS_REPORT
        global NOT_MAPPED_SCENARIOS_REPORT
        global NOT_MAPPED_STORIES_REPORT
        global NOT_MAPPED_BUGS_REPORT
        global JENKINS_REPORT
        MAIN_REPORT = "static/data/main_report_%s.json" % tt
        STORIES_REPORT ="static/data/stories_report_%s.json" % tt
        SCENARIOS_REPORT = "static/data/scenarios_report_%s.json" % tt
        BUGS_REPORT = "static/data/bugs_report_%s.json" % tt
        NOT_MAPPED_SCENARIOS_REPORT = "static/data/not_mapped_scenarios_report_%s.json" % tt
        NOT_MAPPED_STORIES_REPORT = "static/data/not_mapped_stories_report_%s.json" % tt
        NOT_MAPPED_BUGS_REPORT = "static/data/not_mapped_bugs_report_%s.json" % tt
        JENKINS_REPORT ="static/data/jenkins_report.html"
        open(MAIN_REPORT, "w")
        open(STORIES_REPORT, "w")
        open(SCENARIOS_REPORT, "w")
        open(BUGS_REPORT, "w")
        open(NOT_MAPPED_SCENARIOS_REPORT, "w")
        open(JENKINS_REPORT, "w")
    except:
        pass


def printj(s):
    #write/append to jenkins report
    global JENKINS_REPORT
    with open(JENKINS_REPORT, 'a') as outfile:
        outfile.write('%s' % (str(s)))


initReports()
dts = str(args.report_ts)
if dts is None or dts.strip == '': #if not set from script or jenkins - set envVar back to script or jenkins
    dts = t()
    os.environ['report_ts'] = dts
CUR_DIR = os.path.dirname(os.path.abspath(__file__))
if not isPortOpen(args.web_ip, args.web_port):
    #py = 'C:\Users\ibershtein\.windows-build-tools\python27\python2.exe'
    py = sys.executable #Jenkins py3
    cmd = "%s %s\web.py" % (py, CUR_DIR) #manual alias setx python2 "%PATH%;%C:\Users\ibershtein\.windows-build-tools\python27\python2.exe" /M
    runCmd(cmd)
    time.sleep(1)
    if not isPortOpen(args.web_ip, args.web_port): #localhost
        runCmd(cmd)
        time.sleep(1)
        if not isPortOpen(args.web_ip, args.web_port):
            printj("Can't start WebServer")
            raise Exception("Can't start WebServer")


code_path = os.path.join(CUR_DIR, 'code')
git_project = args.git_project #"git@xil01ugitapp01p.newco.global:web-team/webapps.git"
git_branch = args.git_branch #'Nex-Workstation-Infastructure'
git_folder = args.git_folder #'webapps' #Cloning into 'webapps'...
if not (os.path.exists(os.path.join(code_path, git_folder, ".git"))):
    #rmtree(code_path)
    cmd = 'mkdir %s && cd %s && git clone %s && cd %s && git checkout %s && git pull' % (code_path, code_path, git_project, git_folder, git_branch)
else:
    cmd = 'cd %s\%s && git checkout %s' % (code_path, git_folder, git_branch)
print(code_path)
print(cmd)
p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
text = p.stdout.read()
retcode = p.wait()
if isinstance(retcode, str) or retcode != 0:
    printj("Unable to checkout git_branch %s from project %s - %s" % (git_branch, git_project, retcode))
    raise Exception("Unable to checkout git_branch %s from project %s - %s" % (git_branch, git_project, retcode))
    #sys.exit(1)

features_path = os.path.join(CUR_DIR, args.features_path)
print('Job Started, build %s' % dts)
web_ip = args.web_ip #"10.72.8.61" #'localhost'
web_host = 'http://%s' % args.web_addr #'http://%s:5000'


code_features = {}
for filename in os.listdir(features_path):
    if filename.endswith(".feature") and os.path.isfile((os.path.join(features_path, filename))):
        try:
            with open(os.path.join(features_path, filename), 'r') as feature:
                feature_text = feature.read()
                contents = feature_text.split('\n')
                for i in range(len([l for l in contents if l.strip().startswith('#')])):
                    [contents.remove(l) for l in contents if l.strip().startswith('#')]
                updated_feature_text = "\n".join(contents)
                updated_feature_text.replace('"<', '"').replace('>"', '"')
                # if 'orderView' in filename:
                #     print('d comments')
                feature_desc = Parser().parse(updated_feature_text) #(feature.read())
                ##if 'feature' not in feature_desc.keys() or 'name' not in feature_desc['feature'].keys():
                    ##continue #invalid feature
                feature_name = feature_desc['feature']['name']
                feature_tags = [t['name'] for t in feature_desc['feature']['tags'] if
                                 len(feature_desc['feature']['tags']) > 0]  # feature tags
                feature_jira_tags = [f[1:] for f in feature_tags if re.match('@EBS-(\d+)', f, re.IGNORECASE)]
                feature_jira_tag = feature_jira_tags[0] if len(feature_jira_tags) > 0 else 'None'
                ##if feature_jira_tag in 'None':
                    ##continue
                scenario_tags = [t['tags'] for t in feature_desc['feature']['children'] if
                                 len(t['tags']) > 0]  # scenarios_tags
                tags = [code_tag for code_tag in scenario_tags]  # scenarios/stories covered tags
                scenarios_all_tags_list = []
                for tags_list in tags:
                    scenario_tags_list = [tags['name'] for tags in tags_list]
                    [scenarios_all_tags_list.append(t) for t in scenario_tags_list]
                not_tagged_scenarios = [t['name'] for t in feature_desc['feature']['children'] if
                                        len(t['tags']) == 0]  # feature_scenarios_no_tags
                tagged_scenarios = [t['name'] for t in feature_desc['feature']['children'] if
                                        len(t['tags']) > 0]  # feature_scenarios_with_tags
                scenarios_tagged_all_names = [t['name'] for t in feature_desc['feature']['children'] if
                                              len(t['tags']) > 0]
                scenarios_tagged_all_tags = [t['tags'] for t in feature_desc['feature']['children'] if
                                             len(t['tags']) > 0]

                tagged_scenarios_with_tags = []
                for i in range(len(scenarios_tagged_all_tags)):
                    s_tags = [t['name'] for t in scenarios_tagged_all_tags[i]]
                    s_name = scenarios_tagged_all_names[i]
                    tagged_scenarios_with_tags.append({'scenario': s_name, 'tags': s_tags})
                tagged_scenarios_tags = [t['tags'] for t in tagged_scenarios_with_tags]
                not_tagged_scenarios_count = len(not_tagged_scenarios)
                tagged_scenarios_count = len(tagged_scenarios)
                scenarios_list = [t['name'] for t in feature_desc['feature']['children']]
                scenarios_count = len(scenarios_list)
                scenarios_list if len(scenarios_list) > 0 else 'None'

                #feature
                feature_outlines = [o for o in feature_desc['feature']['children'] if
                                    'examples' in o.keys() and len(o['examples']) > 0 and o[
                                        'type'] == 'ScenarioOutline']
                feature_outlines_count = sum(
                    [len(l) for l in [sco['examples'][0]['tableBody'] for sco in feature_outlines]])
                #
                #scenarios
                feature_scenarios_outlines = []
                feature_outlines = [(o, o['name']) for o in feature_desc['feature']['children'] if
                                    'examples' in o.keys() and len(o['examples']) > 0 and o[
                                        'type'] == 'ScenarioOutline']
                feature_wo_outlines = [(o, o['name']) for o in feature_desc['feature']['children'] if
                                       'examples' not in o.keys() and o[
                                           'type'] == 'Scenario']
                tagged_names = [tagged_scenarios_with_tags[i]['scenario'] for i in range(len(tagged_scenarios_with_tags))]
                tagged_tags = [tagged_scenarios_with_tags[i]['tags'] for i in range(len(tagged_scenarios_with_tags))]
                t_tags = []
                t_names = []
                t_counts = []
                for n in tagged_names:
                    scenario_in_outlines = [ot for ot in feature_outlines if n in ot[1]]
                    scenario_no_outlines = [ot for ot in feature_wo_outlines if n in ot[1]]
                    for k in scenario_in_outlines:
                        o = [k][0]
                        outline_tags = [t['name'] for t in k[0]['tags']]
                        for ott in outline_tags:
                            scenario_outline_count = [len(l) for l in [o[0]['examples'][0]['tableBody']]]
                            t_tags.append(ott)
                            t_names.append(n + ' - Scenario Outline: %s' % scenario_outline_count[0])
                            t_counts.append(scenario_outline_count[0])
                    for k in scenario_no_outlines:
                        o = [k][0]
                        outline_tags = [t['name'] for t in k[0]['tags']]
                        for ott in outline_tags:
                            t_tags.append(ott)
                            t_names.append(n)
                            t_counts.append(1)
                    updated_feature_scenarios_count = sum(t_counts)

                jira_issue_link = 'https://jira.nex.com/browse/' + feature_jira_tag if feature_jira_tag is not None and feature_jira_tag not in 'None' and len(feature_jira_tag) > 0 else ''
                code_features[feature_name] = {'feature_jira_tag': feature_jira_tag, 'scenarios_tags': scenarios_all_tags_list,
                                               "not_tagged_scenarios": not_tagged_scenarios,
                                               "not_tagged_scenarios_count": not_tagged_scenarios_count,
                                               "tagged_scenarios": t_names,
                                               "tagged_scenarios_tags":  t_tags,
                                               "tagged_scenarios_count": updated_feature_scenarios_count,
                                               "scenarios_count": scenarios_count, 'issue_link': jira_issue_link,
                                               "feature_file": filename, 'tagged_scenarios_with_tags': tagged_scenarios_with_tags,
                                               "updated_feature_scenarios_count": updated_feature_scenarios_count,
                                               "feature_scenarios_tagged_names": t_names,
                                               "feature_scenarios_tagged_counts": t_counts,
                                               "feature_scenarios_tagged_tags": t_tags,
                                               'build': dts}

            #print('Feature Passed syntax validation: ', filename)
        except Exception as ex:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            error_place = (exc_type, fname, exc_tb.tb_lineno)
            err = 'ERROR: Incorrect format for feature %s %s \n Exception: %s' % (filename, ex, error_place)
            printj(err)
            raise Exception(err)

code_feature_tags = [code_features[t]['scenarios_tags'] for t in code_features if len(code_features[t]['scenarios_tags']) > 0]
code_found_tags = code_feature_tags[0] if len(code_feature_tags[0]) > 0 else []


from jira.client import JIRA
import logging

def getLink(link, label=''):
    if link is None or link == "": #not isinstance(link, unicode): py2 compatible
        return ''
    else:
        label = str(label) #if not isinstance(label, unicode) else label
        return 'https://jira.nex.com/browse/' + link

def r(str):
    return re.sub("[!@#$%^&*()[]{};:,./\\<>?\|`~=+]", "_", str).replace(' ', '_').replace('?', '-').replace('/', '-').replace('\\', '-').strip().replace('%', '-').replace('&', '-').replace('|', '-')


def connect_jira(log, jira_server, jira_user, jira_password):
    '''
    Connect to JIRA. Raise exception on error
    '''
    try:
        log.info("Connecting to JIRA: %s" % jira_server)
        jira_options = {'server': jira_server}
        jira = JIRA(options=jira_options, basic_auth=(jira_user, jira_password))
        return jira
    except Exception as e:
        err_msg = "Failed to connect to JIRA: %s" % e
        printj(err_msg)
        #log.error(err_msg)
        raise err_msg



log = logging.getLogger(__name__)
host = "http://jira.nex.com:8080"
host2 = "http://jiradev:8080"
jc = connect_jira(log, host, "admin", "nexmarkets123")
projects = jc.projects()
jql_str = 'project=EBS'
b = jc.boards()  # ('NEXWS Team Board')

# issuetype in (Feature, Initiative, Story, Sub-task, Bug, Integration) AND ("Assigned Team" = "NEX Workstation" OR "Owning Team" = "NEX Workstation") AND project = "NEX Markets - EBS" ORDER BY Rank ASC
jql_features = 'issuetype in (Feature) AND ("Assigned Team" = "NEX Workstation" OR "Owning Team" = "NEX Workstation") AND project = "NEX Markets - EBS" ORDER BY Rank ASC'
jira_features = jc.search_issues(jql_features, 0, 100000)
jql_stories = 'issuetype in (Story) AND ("Assigned Team" = "NEX Workstation" OR "Owning Team" = "NEX Workstation") AND project = "NEX Markets - EBS" ORDER BY Rank ASC'
jira_stories = jc.search_issues(jql_stories, 0, 100000)
jira_bugs = jc.search_issues("issuetype in (Bug) AND status not in (Closed, Resolved, CANCELLED, DEFERRED, COMPLETED) AND ('Assigned Team' = 'NEX Workstation' OR 'Owning Team' = 'NEX Workstation') AND project = 'NEX Markets - EBS' ORDER BY Rank ASC") #('project=EBS')
jira_bugs_linked_issues = {}
jira_bugs_not_linked_issues = {}
features_issues = u([str(f.key) for f in jira_features if isDefined(f.key)])
for b in jira_bugs:
    found = False
    for bi in b.fields.issuelinks:
        if hasattr(bi, 'outwardIssue'):
            bug_issue = b.key
            if bug_issue not in jira_bugs_linked_issues:
                if isDefined(bi.outwardIssue.key) and bi.outwardIssue.key in features_issues:
                    jira_bugs_linked_issues[bug_issue] = []
                    jira_bugs_linked_issues[bug_issue].append(bi.outwardIssue.key)
                    found = True
                    continue #exit on 1st matched feature
    if not found:
        jira_bugs_not_linked_issues[b.key] = b.key


jira_issues = {}
features = {}
stories = {}
feature_file_by_feature_name = {}
milestone_scenarios = []
feature_scenarios = []
story_scenarios = []
feature_bugs = []
for i in jira_features:
    milestone_feature_scenarios = []
    milestone = i.raw['fields']['fixVersions'][0]['name'] if i.raw['fields']['fixVersions'] is not None and \
                                                             len(i.raw['fields']['fixVersions']) >= 1 and \
                                                             i.raw['fields']['fixVersions'][0][
                                                                 'name'] is not None else "None"
    feature_name = r(i.raw['fields']['summary'])
    feature_issue = i.raw['key']
    feature_link = getLink(feature_issue)
    feature_stories = [s['inwardIssue']['key'] for s in i.raw['fields']['issuelinks'] if 'inwardIssue' in s.keys() \
                       and s['inwardIssue']['fields']['issuetype']['name'] == 'Story']
    feature_all_stories_names = []
    feature_all_stories_issues = []
    feature_all_stories_links = []
    story_scenarios_mapped_tags = []
    story_scenarios_mapped_names = []
    story_scenarios_mapped_files = []
    feature_scenarios_tags_not_mapped = []
    feature_scenarios_not_mapped = []
    feature_scenarios_mapped = []
    feature_scenarios_mapped_tags = []
    for l in feature_stories:
        # if 'EBS-2594' in l:
        #     print('d comments')
        matches = [s for s in jira_stories if s.key == l]
        if len(matches) > 0:
            story_feature = [f for f in jira_features if f.key == i.key][0] if len([f for f in jira_features if f.key == i.key]) > 0 else 'None'
            story_name = r(matches[0].raw['fields']['summary'])
            story_issue = matches[0].raw['key']
            feature_all_stories_issues.append(story_issue)
            feature_all_stories_names.append(story_name)
            feature_all_stories_links.append(getLink(story_issue))
            try:
                for sc in code_features:
                    sc_tags = code_features[sc]['feature_scenarios_tagged_tags']
                    sc_indexes = [si for si, e in enumerate(sc_tags) if e == '@' + story_issue]
                    for sci in sc_indexes:
                        sc_name = code_features[sc]['feature_scenarios_tagged_names'][sci]
                        sc_count = code_features[sc]['feature_scenarios_tagged_counts'][sci]
                        sc_feature_file = code_features[sc]['feature_file']
                        sc_link = '/scenarios?build=%s&scenario_story=%s&scenario_feature=%s&scenario_milestone=%s&scenario_issue_story=%s ' % (dts, story_issue, feature_name, milestone, r(story_issue+' - '+story_name)) if sc_count > 0 else ''
                        story_scenario = {'milestone': milestone, 'feature_issue': feature_issue, 'feature_name': feature_name, 'feature_link': feature_link,
                                                                  'feature_issue_name': feature_issue + ' - ' + feature_name,
                                                                  'story_issue': story_issue,
                                                                  'story_name': story_name,
                                                                  'story_issue_name': story_issue + ' - ' + story_name,
                                                                  'story_link': getLink(story_issue),
                                                                  'story_scenario_name': story_issue + ' - ' + sc_name,
                                                                  'story_scenario_count': sc_count,
                                                                  'story_scenario_file': sc_feature_file,
                                                                  'story_scenarios_link': sc_link
                                          }
                        story_scenarios.append(story_scenario)
                else:
                    # print('Unmatched Story - No matched Scenarios')
                    story_scenario = {'milestone': milestone, 'feature_issue': feature_issue,
                                      'feature_name': feature_name,
                                      'feature_issue_name': feature_issue + ' - ' + feature_name,
                                      'story_issue': story_issue,
                                      'story_name': story_name,
                                      'story_issue_name': story_issue + ' - ' + story_name,
                                      'story_link': getLink(story_issue),
                                      'story_scenario_name': '',
                                      'story_scenario_count': 0,
                                      'story_scenario_file': '',
                                      'story_scenarios_link': '',
                                      }
                    story_scenarios.append(story_scenario)  # Stories & Scenarios Report

            except Exception as ex:
                printj('Exception: ')
                printExcInfo()
                continue
        else:
            #print('Unmatched Story - No matched Scenarios')
            story_scenario = {'milestone': milestone, 'feature_issue': feature_issue, 'feature_name': feature_name,
                              'feature_issue_name': feature_issue + ' - ' + feature_name,
                              'story_issue': story_issue,
                              'story_name': story_name,
                              'story_issue_name': story_issue + ' - ' + story_name,
                              'story_link': getLink(story_issue),
                              'story_scenario_name': '',
                              'story_scenario_count': 0,
                              'story_scenario_file': '',
                              'story_scenarios_link': '',
                              }
            story_scenarios.append(story_scenario) #Stories & Scenarios Report

    #Features Report
    feature_scenarios_count = sum([st['story_scenario_count'] for st in story_scenarios if st['feature_issue'] == feature_issue and not st['story_issue'] is None and st['story_issue'] != 'None' and st['story_issue'] != ''])
    feature_scenarios_link = '/scenarios?scenario_feature=%s&build=%s&scenario_milestone=%s' % (feature_name, dts, milestone) if feature_scenarios_count > 0 else ''
    feature_bugs_count = len([b for b in jira_bugs_linked_issues if feature_issue in jira_bugs_linked_issues[b]])
    feature_bugs_link = '/bugs?milestone=%s&feature=%s&build=%s' % (milestone, feature_name, dts) if feature_bugs_count > 0 else ''
    feature_scenario = {'mile': milestone, 'feature_issue': feature_issue, 'feature_name': r(feature_name), 'feature_link': feature_link,
                          'feature_issue_name': r(feature_issue + ' - ' + feature_name),
                          'stories_count': len(feature_all_stories_issues),
                          'stories_link': '/stories?milestone=%s&feature=%s&build=%s' % (milestone, r(feature_name), dts),
                          'feature_scenarios_count': feature_scenarios_count,
                          'feature_scenarios_link': feature_scenarios_link,
                          'feature_bugs_count': feature_bugs_count,
                          'feature_bugs_link': feature_bugs_link
                        }
    feature_scenarios.append(feature_scenario)


    feature_unique_bugs = set()
    for k in u(jira_bugs_linked_issues.keys()):
        if feature_issue in jira_bugs_linked_issues[k]:
            found = [b for b in jira_bugs if b.key == k]
            if len(found) > 0 and k not in feature_unique_bugs:
                bug = found[0]
                feature_bug = {'mile': milestone, 'feature_issue': feature_issue, 'feature_name': feature_name,
                               'feature_link': feature_link,
                               'feature_issue_name': feature_issue + ' - ' + feature_name,
                               'feature_bug_issue': k,
                               'feature_bug_name': bug.fields.summary,
                               'feature_bug_issue_name': k + ' - ' + bug.fields.summary,
                               'feature_bug_link': 'https://jira.nex.com/browse/%s ' % k,
                               'feature_bug_status': str(bug.fields.status),
                               'feature_bug_priority': str(bug.fields.priority),
                               'feature_bug_assignee': str(bug.fields.assignee),
                               'feature_bug_reporter': str(bug.fields.reporter)
                               }
                feature_bugs.append(feature_bug)  # Bugs Report
                feature_unique_bugs.add(k)


#update features/stories/scenarios counts, remove duplicates in stories
updated_story_scenarios = []
unique_scenarios = set()
for st in story_scenarios:
    duplicate_scenarios = [s for s in story_scenarios if st['story_issue'] in s['story_issue'] and st['story_issue'] not in unique_scenarios]
    # if 'EBS-2594' in st['story_issue']:
    #     print('d duplicate scenarios')
    if st['story_issue'] not in unique_scenarios:
        scenarios_count = sum([sc['story_scenario_count'] for sc in duplicate_scenarios])
        story_details = duplicate_scenarios[0]
        story_details['story_scenario_count'] = scenarios_count
        updated_story_scenarios.append(story_details)
        unique_scenarios.add(st['story_issue'])


#not mapped scenarios
not_mapped_stories = u([sc['story_issue'] for sc in updated_story_scenarios if 'story_scenario_count' not in sc.keys() or sc['story_scenario_count'] <= 0 or sc['story_scenario_count'] is None])
mapped_scenarios = u([sc['story_issue'] for sc in updated_story_scenarios if sc['story_scenario_count'] > 0])
not_tagged_scenarios = [(t['feature_file'], t['not_tagged_scenarios']) for t in [code_features[f] for f in code_features] if len(t['not_tagged_scenarios']) > 0 or len([sct for sct in t['not_tagged_scenarios'] if sct[1:] not in mapped_scenarios and sct[1:].lower() != 'manual']) > 0 ]
tagged_not_mapped_scenarios = {}
for f in code_features:
    for t in code_features[f]['tagged_scenarios_tags']:
        if t[1:] not in mapped_scenarios:
            feature_file = code_features[f]['feature_file']
            if feature_file not in tagged_not_mapped_scenarios.keys():
                tagged_not_mapped_scenarios[feature_file] = {'scenario_tags': [], 'scenario_names': []}
            tagged_not_mapped_scenarios[feature_file]['scenario_tags'].append(t)
            scenario_index = code_features[f]['tagged_scenarios_tags'].index(t)
            tagged_not_mapped_scenarios[feature_file]['scenario_names'].append(code_features[f]['tagged_scenarios'][scenario_index])
for f in not_tagged_scenarios:
    feature_file = f[0]
    if feature_file not in tagged_not_mapped_scenarios.keys():
        tagged_not_mapped_scenarios[feature_file] = {'scenario_tags': [], 'scenario_names': []}
    for sc in f[1]:
        tagged_not_mapped_scenarios[feature_file]['scenario_tags'].append('None')
        tagged_not_mapped_scenarios[feature_file]['scenario_names'].append(sc)
not_mapped_scenarios_report = []
for f in tagged_not_mapped_scenarios:
    for sc in tagged_not_mapped_scenarios[f]['scenario_names']:
        sc_index = tagged_not_mapped_scenarios[f]['scenario_names'].index(sc)
        sc_tag = tagged_not_mapped_scenarios[f]['scenario_tags'][sc_index]
        not_mapped_scenarios_report.append({'feature_file': f, 'scenario_name': sc, 'scenario_tag': sc_tag})
#

#not mapped stories
feature_stories_r = [s['story_issue'] for s in updated_story_scenarios]
not_mapped_stories_r = [jira_stories[i] for i in range(len(jira_stories)) if jira_stories[i].key not in feature_stories_r]
not_mapped_stories_report = []
for i in not_mapped_stories_r:
    not_mapped_story = {"story_issue": i.key, "story_name": i.fields.summary, "story_issue_name": i.key + ' - ' + i.fields.summary, "story_link": "https://jira.nex.com/browse/" + i.key}
    not_mapped_stories_report.append(not_mapped_story)


#not mapped bugs
feature_bugs_report = [{'bug_issue': b.key, 'bug_name': b.fields.summary, 'bug_issue_name': b.key + ' - ' + b.fields.summary,
                        'bug_link': 'https://jira.nex.com/browse/' + b.key} for b in jira_bugs if b.key in jira_bugs_not_linked_issues]
j_not_mapped_bugs_report = json.dumps(feature_bugs_report)
with open(NOT_MAPPED_BUGS_REPORT, 'w') as outfile:
    outfile.write('var not_mapped_bugs_report_%s = ' % dts)
with open(NOT_MAPPED_BUGS_REPORT, 'a') as outfile:
    json.dump(j_not_mapped_bugs_report, outfile)
#


j_not_mapped_stories_report = json.dumps(not_mapped_stories_report)
with open(NOT_MAPPED_STORIES_REPORT, 'w') as outfile:
    outfile.write('var not_mapped_stories_report_%s = ' % dts)
with open(NOT_MAPPED_STORIES_REPORT, 'a') as outfile:
    json.dump(j_not_mapped_stories_report, outfile)


j_not_mapped_scenarios_report = json.dumps(not_mapped_scenarios_report)
with open(NOT_MAPPED_SCENARIOS_REPORT, 'w') as outfile:
    outfile.write('var not_mapped_scenarios_report_%s = ' % dts)
with open(NOT_MAPPED_SCENARIOS_REPORT, 'a') as outfile:
    json.dump(j_not_mapped_scenarios_report, outfile)

j_main_report = json.dumps(feature_scenarios)
with open(MAIN_REPORT, 'w') as outfile:
    outfile.write('var main_report_%s = ' % dts)
with open(MAIN_REPORT, 'a') as outfile:
    json.dump(j_main_report, outfile)


j_stories_report = json.dumps(updated_story_scenarios)
with open(STORIES_REPORT, 'w') as outfile:
    outfile.write('var stories_report_%s = ' % dts)
with open(STORIES_REPORT, 'a') as outfile:
    json.dump(j_stories_report, outfile)


j_story_code_scenarios = json.dumps(story_scenarios)
with open(SCENARIOS_REPORT, 'w') as outfile:
    outfile.write('var scenarios_report_%s = ' % dts)
with open(SCENARIOS_REPORT, 'a') as outfile:
    json.dump(j_story_code_scenarios, outfile)


j_bugs_report = json.dumps(feature_bugs)
with open(BUGS_REPORT, 'w') as outfile:
    outfile.write('var bugs_report_%s = ' % dts)
with open(BUGS_REPORT, 'a') as outfile:
    json.dump(j_bugs_report, outfile)


printj("<a href='%s/?build=%s'>View report</a>" % (web_host, dts))
print("Job Finished, build %s" % dts)
print('View report at %s/?build=%s' % (web_host, dts))

sys.exit(0)

#Jenkins 10.72.2.85
#String Params:
#git_project git@xil01ugitapp01p.newco.global:web-team/webapps.git
#git_branch Nex-Workstation-Infastructure

# # Win CMD batch command
# C:\Users\tlvuser\AppData\Local\Programs\Python\Python36\python.exe -V
# cd C:\Users\tlvuser\PycharmProjects\WsMilestoneReport\test
# to fix start with jenkinsRetry + errorLogger
#start C:\Users\tlvuser\AppData\Local\Programs\Python\Python36\python.exe web.py
# C:\Users\tlvuser\AppData\Local\Programs\Python\Python36\python.exe jira2git.py
#or
#python -V
# python jira2git.py

# # html report
# C:\Users\tlvuser\PycharmProjects\WsMilestoneReport\test\static\data
# jenkins_report.html
#


#BugFix in CukeParser file token_scanner.py
# def isFeatureFile(self, path_or_str):
#     try:
#         return os.path.exists(path_or_str)
#     except:
#         return False
#
#
# def __init__(self, path_or_str):
#     if self.isFeatureFile(path_or_str):
#         self.io = io.open(path_or_str, 'rU', encoding='utf8')
#     else:
#         if sys.version_info < (3, 0):
#             if isinstance(path_or_str, str):
#                 self.io = io.StringIO(unicode(path_or_str, encoding='utf8'))
#             else:
#                 self.io = io.StringIO(path_or_str)
#         else:
#             self.io = io.StringIO(path_or_str)
#     self.line_number = 0