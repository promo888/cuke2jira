var friendsData = [
  {
    "name": "Zhorik",
    "secondName": "Joshnson",
    "phone": "380963336667"
  },
  {
    "name": "Zhorik",
    "secondName": "Joshnson",
    "phone": "380963336667"
  },
  {
    "name": "Zhorik",
    "secondName": "Joshnson",
    "phone": "380963336667"
  },
  {
    "name": "Zhorik",
    "secondName": "Joshnson",
    "phone": "380963336667"
  },
  {
    "name": "Zhorik",
    "secondName": "Joshnson",
    "phone": "380963336667"
  }
];
