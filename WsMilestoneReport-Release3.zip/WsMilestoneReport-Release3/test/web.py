import os
from flask import Flask, render_template, request #import main Flask class and request object
from flask import send_from_directory
app = Flask(__name__, static_url_path='', template_folder='static')  #create the Flask app

def r(str):
    if str is None:
        return str
    return str.replace(' ', '_').replace('?', '-').replace('/', '-').replace('\\', '-').strip().replace('%', '-').replace('&', '-').replace('|', '-')


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.getcwd(), 'favicon.ico', mimetype='image/vnd.microsoft.icon')


@app.route('/')
def query_root():
    build = request.args.get('build')
    return render_template('main_report.html', title='NEX WS Milestones Report', build=build)


@app.route('/nex-ws')
def query_nexws():
    build = request.args.get('build')
    #return app.send_static_file('main_report.html')
    return render_template('main_report.html', title='NEX WS Milestones Report', build=build)



@app.route('/stories', methods=['GET', 'POST'])
def query_stories():
    mile = request.args.get('milestone')
    feat = request.args.get('feature')
    build = request.args.get('build')

    #return app.send_static_file('stories_report.html') #render_template('report.html', title='NEX WS Stories Report')
    return render_template('stories_report.html', title='NEX WS Stories Report', milestone=mile, feature=feat, build=build) #**locals())


@app.route('/scenarios', methods=['GET', 'POST'])
def query_scenarios():
    mile = request.args.get('scenario_milestone')
    feat = request.args.get('scenario_feature')
    story_issue = request.args.get('scenario_story')
    story_name = request.args.get('scenario_issue_story')
    build = request.args.get('build')

    if story_issue is not None and story_issue != '':
        return render_template('scenarios_report.html', title='NEX WS Scenarios Story Report', scenario_milestone=mile, scenario_feature=feat, scenario_story=story_issue, scenario_issue_story=story_name, build=build) #*storiesReport
    else:
        return render_template('scenarios_report.html', title='NEX WS Scenarios Feature Report', scenario_milestone=mile, scenario_feature=feat, build=build) #featuresReport


@app.route('/bugs', methods=['GET', 'POST'])
def query_bugs():
    mile = r(request.args.get('milestone'))
    feat = r(request.args.get('feature'))
    story = r(request.args.get('scenario_story'))
    build = request.args.get('build')

    if story is not None and story != '':
        return render_template('bugs_report.html', title='NEX WS Bugs Report', scenario_milestone=mile, scenario_feature=feat, scenario_story=story, build=build) #**locals())
    else:
        return render_template('bugs_report.html', title='NEX WS Bugs Report', scenario_milestone=mile, scenario_feature=feat, build=build)


@app.route('/not_mapped_scenarios', methods=['GET', 'POST'])
def query_not_mapped_scenarios():
    build = request.args.get('build')
    return render_template('not_mapped_scenarios_report.html', title='NEX WS Not Mapped Scenarios Report', build=build)


@app.route('/not_mapped_stories', methods=['GET', 'POST'])
def query_not_mapped_stories():
    build = request.args.get('build')
    return render_template('not_mapped_stories_report.html', title='NEX WS Not Mapped Stories Report', build=build)


@app.route('/not_mapped_bugs', methods=['GET', 'POST'])
def query_not_mapped_bugs():
    build = request.args.get('build')
    return render_template('not_mapped_bugs_report.html', title='NEX WS Not Mapped Bugs Report', build=build)


def startWebServer(port):
    print('Starting Flask')
    app.run(host='0.0.0.0', port=port)
    print('Flask Started')


if __name__ == '__main__':
    print('Starting Flask')
    app.run(host='0.0.0.0', debug=True, port=5000) #run app in debug mode on port 5000
    print('Flask Started')